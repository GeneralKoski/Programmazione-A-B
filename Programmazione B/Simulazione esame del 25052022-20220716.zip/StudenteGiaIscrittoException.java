package esame;

public class StudenteGiaIscrittoException extends Exception {

}
