package esame;

public class StudenteGiaVerbalizzatoException extends Exception{

}
