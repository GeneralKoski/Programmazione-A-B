package esame;

public class StudenteNonIscrittoException extends Exception {
	
}
